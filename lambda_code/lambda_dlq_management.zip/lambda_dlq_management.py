import boto3
import os
import traceback

def lambda_handler(event, context):
    print(">>> START EXECUTION <<<")
    print(">>> END EXECUTION <<<")
    return True
